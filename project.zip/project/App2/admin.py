from django.contrib import admin
from App2.models import *

admin.site.register(Account_Details)
