from django.urls import path
from App2 import views

urlpatterns=[
    path('nav',views.nav,name='nav'),
    path('cart',views.cart,name='cart'),
    path('iphone',views.iphone,name='iphone'),
    path('oneplus',views.oneplus,name='oneplus'),
    path('oppo',views.oppo,name='oppo'),
    path('pixel',views.pixel,name='pixel'),
    path('poco',views.poco,name='poco'),
    path('realmi',views.realmi,name='realmi'),
    path('redmi',views.redmi,name='redmi'),
    path('samsung',views.samsung,name='samsung'),
    path('vivo',views.vivo,name='vivo'),
    path('',views.wstore,name='wstore'),
    path('login',views.login,name='login'),
    path('pay',views.pay,name='pay')
]