from django.shortcuts import render

# Create your views here.
def nav(request):
    return render(request,'navigation.html')
def wstore(request):
    return render(request,'wstore.html')
def  cart(request):
    return render(request,'cart.html')
def iphone(request):
    return render(request,'iphone.html')
def vivo(request):
    return render(request,'vivo.html')
def samsung(request):
    return render(request,'samsung.html')
def oneplus(request):
    return render(request,'oneplus.html')
def realmi(request):
    return render(request,'realmi.html')
def redmi(request):
    return render(request,'redmi.html')
def oppo(request):
    return render(request,'oppo.html')
def pixel(request):
    return render(request,'pixel.html')
def poco(request):
    return render(request,'poco.html')
def login(request):
    return render(request,'login.html')
def pay(request):
    return render(request,'payment.html')