from django.shortcuts import redirect, render
from django.http import HttpResponse,HttpResponseRedirect

def Index(request):
    return render(request,'index.html')

def home(request):
    return render(request,'home.html')

def boot(request):
    return render(request,'boot.html')

def pack(request):
    return render(request,'pack.html')