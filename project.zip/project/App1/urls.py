from django.urls import path
from . import views
urlpatterns=[
    path('home',views.Index,name='Index'),
    path('',views.home,name='home'),
    path('boot',views.boot,name='boot'),
    path('pack',views.pack,name='pack')
]